﻿


var LoginData=function(){
  var email="kashancontour@gmail.com"
  var password="goldsmith123"
  
}