﻿
/*-----------------------------------Logs---------------------------

Created By: Kashan Malik
Summary:
Date:

-----------------------------------------------------------------------------*/


  
function Stepcomment(Message){
  
  Indicator.PopText();
  Log.PopLogFolder();
  
  Log.AppendFolder(Message);
  Indicator.PushText(Message);
  
  }

module.exports.Stepcomment = Stepcomment;