﻿var LoginData = require("LoginData");
var ActiononObject = require("ActiononObject");
var Logs = require("Logs");


function Login(){
  //Navigate to LoginPage
Browsers.Item(btChrome).Navigate("https://www.goldsmiths.co.uk");

  //Login Functionality
 let page=Aliases.browser.pageGoldsmiths;
 
 Logs.Stepcomment("Click on Sigin button")
 Aliases.browser.pageGoldsmithsJewellersWatchesDi.linkSignInOrRegister.Click();
  page.Wait();
  
  Logs.Stepcomment("Click on Login form")
  let textNode = page.textnode;
  textNode.textnodeIAmAReturningCustomer.Click();
  
   Logs.Stepcomment("Enter Login Details")
  let textbox = textNode.formLoginform;
  let email = textbox.textboxEmailAddress;
  ActiononObject.TextWrite(email,"kashancontour@gmail.com");
  let password = textbox.passwordboxPassword;
  ActiononObject.TextWrite(password,"goldsmith123");
  textbox.submitbuttonSignIn.ClickButton();





}