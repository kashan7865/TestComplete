﻿

/*-----------------------------------Method to send keys---------------------------

Created By: Kashan Malik
Summary:
Date:

-----------------------------------------------------------------------------*/

function TextWrite(Object,Text){
  Object.Keys(Text);
  Object.Keys("[Tab]");
  return;
}
module.exports.TextWrite = TextWrite;