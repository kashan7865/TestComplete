﻿function Test1()
{
  Browsers.Item(btChrome).Navigate("https://www.goldsmiths.co.uk/?logout=true");
  let browser = Aliases.browser;
  browser.BrowserWindow.Maximize();
  let page = browser.pageGoldsmiths;
  page.linkSignInOrRegister.Click();
  page.Wait();
  let textNode = page.textnode;
  textNode.textnodeIAmAReturningCustomer.Click();
  let textbox = textNode.formLoginform;
  let textbox2 = textbox.textboxEmailAddress;
  textbox2.SetText("kashancontour@gmail.com");
  let passwordBox = textbox.passwordboxPassword;
  passwordBox.SetText(Project.Variables.Password1);
  textbox.submitbuttonSignIn.ClickButton();
  page = browser.pageGoldsmiths2;
  page.Wait();
  textbox = page.formSearchForm.textboxSliSearch1;
  textbox.Click();
  textbox.SetText("rolex");
  textbox.Keys("[Enter]");
}