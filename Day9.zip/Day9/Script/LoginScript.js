﻿function Login()
{
  var Username, Password, functionvalue;
  Username = "kashancontour";
  Password = "123456";
  functionvalue = "";
  //Running Browser
  //Opens the specified URL in a running instance of the specified browser.
  Browsers.Item(btChrome).Navigate("https://adactinhotelapp.com/");
  //Maximizes the specified Window object.
  Aliases.browser.BrowserWindow.Maximize();
  //Delays the test execution for the specified time period.
  Delay(500);
  //Enter user credentials
  //Runs a test from the project.
  //Unable to convert the Run Test operation (Test name: "Script\Unit1 - username").
  functionvalue = LastResult;
  //Sets the text KeywordTests.Test1.Variables.functionvalue in the 'Username' text editor.
  Aliases.browser.Hotel.Loginform.Username.SetText(functionvalue);
  //Checks whether the 'Text' property of the Aliases.browser.Hotel.Loginform.Username object equals 'kashancontour'.
  aqObject.CheckProperty(Aliases.browser.Hotel.Loginform.Username, "Text", cmpEqual, "kashancontour", false);
  if(Aliases.browser.Hotel.Loginform.Username.Text == "kashancontour")
  {
    //Sets the text Project.Variables.Password1 in the 'Password' text editor.
    Aliases.browser.Hotel.Loginform.Password.SetText(Project.Variables.Password1);
    //Clicks the 'Loginbutton' button.
    Aliases.browser.Hotel.Loginform.Loginbutton.ClickButton();
  }
  else
  {
    //Sets the text KeywordTests.Test1.Variables.Password in the 'Password' text editor.
    Aliases.browser.Hotel.Loginform.Password.SetText(Password);
    //Clicks the 'Loginbutton' button.
    Aliases.browser.Hotel.Loginform.Loginbutton.ClickButton();
  }
}