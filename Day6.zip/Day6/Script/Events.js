﻿function EventControl1_OnStopTest(Sender)
{
  Log.Message("Test case passsed successfully")

}