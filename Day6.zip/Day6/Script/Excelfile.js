﻿


function main(){ 
    var path=Project.Path+"Testdata\\Testdataexcel.xlsx"
    var driver=DDT.ExcelDriver(path,"Testdata1",true);

while(!driver.EOF()){
  if(aqString.Compare(driver.Value("Active"),"yes",false)==0){
  Adduser(driver.Value("Quantity"),driver.Value("Customer Name"),driver.Value("Street"),driver.Value("City"),driver.Value("State"),driver.Value("Zip"),driver.Value("Card No"));
  }
  driver.Next();

}
DDT.CloseDriver(driver.Name);
}

function Adduser(Quantity,Name,Street,City,State,Zipcode,Cardno)
{
  TestedApps.Orders.Run(1, true);
  let orders = Aliases.Orders;
  orders.MainForm.MainMenu.Click("Orders|New order...");
  let orderForm = orders.OrderForm;
  let groupBox = orderForm.Group;
  groupBox.Quantity.wValue = Quantity;
  let textBox = groupBox.Customer;
  textBox.SetText(Name);
  textBox = groupBox.Street;
  textBox.SetText(Street);
  textBox = groupBox.City;
  textBox.SetText(City);
  textBox = groupBox.State;
  textBox.SetText(State);
  textBox = groupBox.Zip;
  textBox.SetText(Zipcode);
  groupBox.MasterCard.ClickButton();
  textBox = groupBox.CardNo;
  textBox.SetText(Cardno);
  groupBox.ExpDate.wDate = "2005-05-06";
  orderForm.ButtonOK.ClickButton();
}