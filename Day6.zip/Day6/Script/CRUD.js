﻿
/*Function to add order*/
function addorder()
{
  Log.AppendFolder("Adding new order")
  let orders = Aliases.Orders;
  orders.MainForm.MainMenu.Click("Orders|New order...");
  aqUtils.Beep(3000);  //Aqutilswait
  let orderForm = orders.OrderForm;
  let groupBox = orderForm.Group;
  Log.AppendFolder("Seting Quantity");
  groupBox.Quantity.wValue = 20;
  Log.PopLogFolder();
  let textBox = groupBox.Customer;
  textBox.SetText("john6");
  var res=textBox.WaitProperty("Exists",true,1000); //Wait property
  Log.Message(res);
  textBox = groupBox.Street;
  textBox.SetText("21");
  textBox = groupBox.City;
  textBox.SetText("isb");
  textBox = groupBox.State;
  textBox.SetText("punjab");
  groupBox.AE.ClickButton();
  Delay("2000"); // Builtin Delay command
  orderForm.ButtonOK.ClickButton();
  
  Log.PopLogFolder();
}


/*Method to check is order is available in list by user name*/
function Isorderinlist(custname){
  var mainform=Aliases.Orders.MainForm;

  var orderview=mainform.OrdersView;
  var itemcount=orderview.wItemCount;
  Log.Message(itemcount);
  var result=-1;
  var custcol=0;
  
  for(var index=0; index<itemcount; index++){
    var name=orderview.wItem(index,custcol);
    Log.Message(name);
    if(aqString.Compare(name, custname ,false)==0)
    {
      Log.Message("Name found in list at index: "+index);
      result=index;
      break;
    }
    }
     return result;
  
}

/*Method to check if the order is with the same name*/
function Multiplordernameinlist(custname,start){
  var mainform=Aliases.Orders.MainForm;
  var orderview=mainform.OrdersView;
  var itemcount=orderview.wItemCount;
  Log.Message(itemcount);
  var result=-1;
  var custcol=0;
  
  for(var index=(typeof start=="undefined")? 0 : start; index<itemcount; index++){
    var name=orderview.wItem(index,custcol);
    Log.Message(name);
    if(aqString.Compare(name, custname ,false)==0)
    {
      Log.Message("Name found in list at index: "+index);
      result=index;
      break;
    }
    }
     return result;
  
}

/*Method to delete an order*/
function deleteorder(custname){
  var orderindex=Isorderinlist(custname);
  
  var mainform=Aliases.Orders.MainForm;
  var orderview=mainform.OrdersView;
   var custcol=0;
   var deletebutton=6;
   var result=false;
   
   orderview.ClickItem(orderindex,custcol);
   mainform.ToolBar.ClickItem(deletebutton);
   var dlgconbox=Aliases.Orders.dlgConfirmation;
   if(dlgconbox.Exists==true){
     dlgconbox.btnYes.ClickButton();
     result=true;
   }
   return result; 
  
}

/*Method to edit an order*/
function editorder(custname,newqty,totalexp,expunitprice){
  
  var editindex=Isorderinlist(custname);
  var mainform=Aliases.Orders.MainForm;
  var orderview=mainform.OrdersView;
  var custcol=0;
  var editbutton=5;
   
   orderview.ClickItem(editindex,custcol);
   mainform.ToolBar.ClickItem(editbutton);
   
   Aliases.Orders.OrderForm.Group.Quantity.UpDownEdit.SetText(newqty);
   Aliases.Orders.OrderForm.Group.Quantity.UpDownEdit.Keys("[Enter]");
   
   aqObject.CheckProperty(Aliases.Orders.OrderForm.Group.groupBox1.Total, "wText", cmpEqual, totalexp);
   //aqObject.CheckProperty(Aliases.Orders.OrderForm.Group.Price, "wText", cmpEqual, "$100");
   //aqObject.CheckProperty(Aliases.Orders.OrderForm.Group.Price, "wText", cmpEqual, "$100", false);
  //aqObject.CheckProperty(Aliases.Orders.OrderForm.Group.Price, "wText", cmpEqual, "$100",false);
  
  if(aqString.Compare(Aliases.Orders.OrderForm.Group.Price.wText,expunitprice,false)==0){   //Other method to check property
    Log.Checkpoint("Unit price matched Successfully"+expunitprice);
  }
  else{
    Aliases.Orders.OrderForm.ButtonCancel.ClickButton();
    Log.Error("Unit price is not equal","Unit price value:"+expunitprice+" Actual value: "+Aliases.Orders.OrderForm.Group.Price.wText);
  }
   Aliases.Orders.OrderForm.ButtonOK.ClickButton();
   
}

/*Mian class*/
function Main(){
 // var result=Isorderinlist("john");
  //Log.Message("Order is at index: "+result);
  
  /*var orderdeleted=deleteorder("john");
  Log.Message("Order is deleted successfully: "+orderdeleted);*/
  
 /* var result1=Multiplordernameinlist("john",2);
  Log.Message("Order is at index: "+result1);*/
  
  var result=editorder("john",30, 2760,"$10");
  Log.Message("Order edited successfully");
}


/*Function to check object propertoes at runtime*/
function searchobject(){
  var mainform=Aliases.Orders.MainForm;
  var obj=mainform.FindChild("Name","WinFormsObject(\"OrdersView\")",3);
  Log.Message(obj.Exists);
  Log.Message(obj.wItem(0,0));
}

  module.exports.foo=5;// To export a variable in other scripts

/*Export Function in other Scripts*/
module.exports.Isorderinlist = Isorderinlist;
module.exports.Multiplordernameinlist = Multiplordernameinlist;
module.exports.deleteorder = deleteorder;
module.exports.editorder = editorder;
module.exports.Main = Main;
module.exports.addorder = addorder();