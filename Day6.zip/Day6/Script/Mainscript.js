﻿
/*Script to call function and variables from other Scripts*/
var CRUD = require("CRUD");

function main(){
 var result=CRUD.Isorderinlist("ABC");
 Log.Message("Order is at index: "+result);
 
 Log.Message(CRUD.foo);
 
}
