﻿

function Main(){
  
var path=Project.Path+"Testdata\\Testdata1.csv";
var driver=DDT.CSVDriver(path);

driver.DriveMethod("Csvdrivemethod.addorder");

DDT.CloseDriver(driver.Name);
}

function addorder()
{
  let orders = Aliases.Orders;
  orders.MainForm.MainMenu.Click("Orders|New order...");
  aqUtils.Beep(3000);  //Aqutilswait
  let orderForm = orders.OrderForm;
  let groupBox = orderForm.Group;
  groupBox.Quantity.wValue = DDT.CurrentDriver.Value("Quantity");
  let textBox = groupBox.Customer;
  textBox.SetText(DDT.CurrentDriver.Value("Customer Name"));
  var res=textBox.WaitProperty("Exists",true,1000); //Wait property
  Log.Message(res);
  textBox = groupBox.Street;
  textBox.SetText(DDT.CurrentDriver.Value("Street"));
  textBox = groupBox.City;
  textBox.SetText(DDT.CurrentDriver.Value("City"));
  textBox = groupBox.State;
  textBox.SetText(DDT.CurrentDriver.Value("State"));
  groupBox.AE.ClickButton();
  Delay("2000"); // Builtin Delay command
  orderForm.ButtonOK.ClickButton();
}