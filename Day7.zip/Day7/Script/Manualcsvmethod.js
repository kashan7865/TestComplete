﻿

function main(){ 
    var path=Project.Path+"Testdata\\Testdata1.csv"
var driver=DDT.CSVDriver(path);

while(!driver.EOF()){
  
}
}