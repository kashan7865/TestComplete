﻿

var folderiderrors;
var folderidmessages;

function Main(){
  folderiderrors=Log.AppendFolder("Global errors");
  Log.PopLogFolder();
  
  folderidmessages=Log.AppendFolder("Global Messages");
  Log.PopLogFolder();
  
  createmessage();
}

function createmessage(){
  Log.Message("Message 1","",300,"","",folderidmessages);
  Log.Message("Error 1","",300,"","",folderiderrors)
}