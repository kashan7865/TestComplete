﻿var Operators = require("Operators");

function test(){
  var a=1;
  Log.Message(typeof a);
}

function test1(){
  var b=Scopescriptvar.Operators;
  Log.Message(b);
}