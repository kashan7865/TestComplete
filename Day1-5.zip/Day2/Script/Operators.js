﻿ var z=100;

function main(){
  operators();
  increment();
  decrement();
}

function operators(){
  var x=1;
  var y=2;
  Log.Message(x+y);
  Log.Message(x-y);
  Log.Message(x*y);
  Log.Message(x/y);
  Log.Message(x%y);
}

function increment(){
  var x=5;
  var y=10;
  ++y;
 Log.Message(x++);
 Log.Message(y);
}

function decrement(){
  var x=5;
  var y=10;
  --y;
 Log.Message(x--);
 Log.Message(y);
 Log.Message(z);
}
module.exports.decrement = decrement;