﻿
function conversion(){
  var playername=BuiltIn.InputBox("caption","Enter player name","");
  var age=BuiltIn.InputBox("caption","Enter age","");
  var duration=BuiltIn.InputBox("caption","How long he will play","");
  
  var retirementage=VarToInt(age)+VarToInt(duration)
  Log.Message(playername+" will retire in age of "+retirementage)
}