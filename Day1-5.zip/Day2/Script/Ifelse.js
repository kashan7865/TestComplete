﻿ 

function test(){
  var playername=BuiltIn.InputBox("caption","Enter player name","");
  var age=BuiltIn.InputBox("caption","Enter age","");
  var duration=BuiltIn.InputBox("caption","How long he will play","");
  var speed=BuiltIn.InputBox("","Enter bowler speed","");
  
  var retirementage=VarToInt(age)+VarToInt(duration)
  Log.Message(playername+" will retire in age of "+retirementage)
  
  if(speed>=150){
    Log.Message("Bowler speed is fast")
  }
  else if(speed>=100 && speed<150 ) {
    Log.Message("Bowler speed is medium")
  }
  else{
  Log.Message("Bowler speed is slow")
  }
  }

function terninaryoperator(){
  var age=VarToInt(BuiltIn.InputBox("caption","Enter age",""));
  var voteable=(age>18) ? "too young": "old enough";
  Log.Message("person age is "+ voteable);
}
