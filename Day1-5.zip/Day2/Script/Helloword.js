﻿ 


function firstprogram(){
  Log.Message("Hello World")
}

function secondprogram(){
  var name="ali", no=5, state=true; 
  Log.Message(name);
  Log.Message(no);
  Log.Message(state);
}
module.exports.firstprogram = firstprogram;
module.exports.secondprogram = secondprogram;