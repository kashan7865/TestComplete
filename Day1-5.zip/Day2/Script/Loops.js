﻿

function forloop(){
 for(i=0;i<+10;i++){
   for(y=1;y<3;y++){
     Log.Message("Value of i= "+i+"and Value of y= "+y)
   }
 }
 }
 
 function continueforloop(){
   for(i=0;i<+10;i++){
     if(i==5)
     continue;
     Log.Message("Value of i= "+i)
   }
}

function dowhile(){
  var password=5;
  var tries=0;
  do
  {
  var pass=VarToInt(BuiltIn.InputBox("Caption","Enter your password",""));
  if(pass==password){
    Log.Message("Password is correct");
    break;
  }
  else{
    ShowMessage("Wrong password");
    tries++;
  }
  
  }while (tries<3);
  Log.Message("Account locked");
}