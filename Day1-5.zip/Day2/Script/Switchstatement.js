﻿  function Switch(){
    var option=VarToInt(BuiltIn.InputBox("caption","Select the bowling option 1-Fast, 2-Medium, 3-Slow",""));
    
    switch ( option )
    {
      case 1 :
    Log.Message("Bowler is fast");
        break;
    
      case 2 :
    Log.Message("Bowler is medium");
        break;
        
        case 3 :
    Log.Message("Bowler is slow");
        break;
        
        default:
        Log.Message("None is selected");
    }
    
  }