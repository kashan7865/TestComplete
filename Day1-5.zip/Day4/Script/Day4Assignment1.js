﻿/*Write a program to compare two dates of different formats are the same.
	Dt1 = “08/02/15” 		// dd/mm/yy
	Dt2 = “02/08/15”			// mm/dd/yy
Output:
Input dates are equal.*/


function Comparedates(){
  var dt1="01/10/2021";
  var dt2="10/01/2021";
  var dt3=aqConvert.DateTimeToFormatStr(dt2,"%m/%d/%y");
  
  Log.Message(aqDateTime.Compare(dt1,dt3));
  

}