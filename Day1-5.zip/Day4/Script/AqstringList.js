﻿

function liststring(){
  var str="Honda|model|is|2016";
  aqString.ListSeparator=("|");
  Log.Message(aqString.GetListLength(str));
  Log.Message(aqString.GetListItem(str,1));
  Log.Message(aqString.AddListItem(str,"2018",4));
  Log.Message(aqString.ChangeListItem(str,"2017",3));
  Log.Message(aqString.DeleteListItem(str,2));
  
}