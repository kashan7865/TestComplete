﻿

function aqstring(){
  var x="Honda";
  var y="honda"
  
  Log.Message(aqString.Compare(x,y,true));
  Log.Message(aqString.ToLower(x));
  
  var cars="bmw, honda, nissan"
  Log.Message(aqString.Find(cars,"a",1,false));
  Log.Message(aqString.FindLast(cars,"a",false));
  Log.Message(aqString.SubString(cars,5,5));
  
  }
  
function formatspecifiers(){
  Log.Message(aqString.Format("My name is %s and I am %i years old and i live in %s","john",20,"ISB"));
}