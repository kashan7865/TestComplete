﻿
function DateTime(){
  var dt=aqDateTime.Now();
  Log.Message("Today date is:"+dt);
}

function DateTimeMethods(){
  var dt=aqDateTime.Now();
  Log.Message("Today date is:"+dt);
  
var dt=aqDateTime.AddDays(dt,5); 
Log.Message("Today date is:"+dt);

var dt=aqDateTime.AddMonths(dt,2); 
Log.Message("Today date is:"+dt);

}

function Datetimeformatters(){
   var dt=aqDateTime.Today();
   var dt1=aqConvert.DateTimeToFormatStr(dt1,"%b %d %Y")
   var dt2=aqConvert.DateTimeToStr(dt);
   Log.Message("Today date is:"+dt);
   Log.Message("Today date is:"+dt1);
   Log.Message("Today date is:"+dt2);
}

function Comparedates(){
  var dt1="01/10/2021";
  var dt2="10/01/2021";
  var dt3=aqConvert.DateTimeToFormatStr(dt2,"%m/%d/%y");
  
  Log.Message(aqDateTime.Compare(dt1,dt3));
  Log.Message(dt3);

}