﻿/*The diameter of the Sun is approximately 865,000 miles. The diameter of the Earth is approximately 7,600 miles. Use the methods in the class Math to calculate:               Hint(volume of sphere = 4/3 x PI x radius3) 
The volume of the Earth in cubic miles
The volume of the Sun in cubic miles
The ratio of the volume of the Sun to the volume of the Earth*/

function test(){
   var sunRad = 865000.0/2.0;                                      // Sun radius in miles is half the diameter
    var earthRad = 7600.0/2.0;                                      // Earth radius likewise
    var fourOverThree = 4.0/3.0;                                    // A convenient constant, 4/3
    
    
    // Find the volumes of earth and sun:
    var earthVol = fourOverThree*Math.PI*Math.pow(earthRad,3);
    var sunVol = fourOverThree*Math.PI*Math.pow(sunRad,3);
    // Find the ratio of their volumes:
    var ratioVol = sunVol/earthVol;
 
    // Output the results:
    Log.Message(("Volume of the earth is " + earthVol + " cubic miles"));
    Log.message(("Volume of the sun is " + sunVol + " cubic miles"));
    Log.message(("The sun's volume is " + ratioVol + " times greater than the earth's."));
}
