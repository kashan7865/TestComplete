﻿
function mathrandom(){

  var i,randomval;
  for(i=1;i<10;i++){
     randomval=Math.random()*100;
     Log.Message(randomval); 
  }
  }