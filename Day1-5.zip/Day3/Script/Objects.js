﻿
//Method to declare an object
function objects(){
  var person={name:"saad", age:10, eyecolor:"black"};
  person.age=30;
  
  var x;
  for(x in person){
    Log.Message(person[x]);
  }
// Another method of declaring object
  var persons = new Object();
  persons.firstName = "John";
  persons.lastName = "Doe";
  persons.age = 50;
  persons.eyeColor = "blue";
var y;
  for(y in persons){
    Log.Message(persons[y]);
  }
}