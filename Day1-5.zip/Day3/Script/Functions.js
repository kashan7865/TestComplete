﻿

function add(var1,var2,var3){
  if(typeof var3=="number"){
    return(var1+var2+var3);
  }
  else{
    return(var1+var2);
  }
}

function main(){
  var result=add(1,2,"5");
  Log.Message(result);
}