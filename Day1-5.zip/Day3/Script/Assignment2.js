﻿/*Write a program to check if a string is palindrome?*/

function palindromeFun (str )  
{  
// convert the string into an array using the string.split() function  
const arrValue = str.split (''); //   
  
// use reverse() method to reverse the array values  
const reveArrVal = arrValue.reverse();   
  
// use join() method to group the array values into the string  
const revString = reveArrVal.join('');  
  
if (str == revString) // if string condition is equal to the revString  
{  
Log.Message("It is a Palindrome string");  
}  
else {  
Log.Message("It is not a Palindrome string");   
}  
}  

function main(){
// take a string from the user  
var string=VarToString(BuiltIn.InputBox("No","Enter the no or string",""));
//const string = prompt( ' Enter the string to check Palindrome ');  
var value = palindromeFun (string); // call the function  
}