﻿

function objects(name,age,color){
  this.name=name;
  this.age=age;
  this.color=color;
}

function main(){
  var obj1=new objects("abc",10,"brown");
  for(var x in obj1){
    Log.Message(x+"property is"+obj1[x]);
  }
}