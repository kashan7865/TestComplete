﻿
/*Arrays in javascipt*/
function arrays(){
  var cars=["Bmw","honda","toyota"];
  
  for(var i=0; i<cars.length; i++){
  Log.Message("Cars are:"+cars[i]);
  }
}
/*Add an element into array*/

function addelement(){
  var cars=["Bmw","honda","toyota"];
  cars[cars.length]="Nisan"
  
  for(var i=0; i<cars.length; i++){
  Log.Message("Cars are:"+cars[i]);
  }
}
/*Splice an element in array*/
function spliceelement(){
  var cars=["Bmw","honda","toyota"];
  cars.splice(0,0,"Nisan");
  
  for(var i=0; i<cars.length; i++){
  Log.Message("Cars are:"+cars[i]);
  }
}

/*Sort an array*/

function sorting(){
  var cars=["Bmw","honda","toyota"];
  cars.splice(0,0,"Nisan");
  cars.sort();
  //cars.reverse();
  
  for(var i=0; i<cars.length; i++){
  Log.Message("Cars are:"+cars[i]);
  }
}