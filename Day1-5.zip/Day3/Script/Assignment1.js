﻿/*Write a program which accepts numbers as arguments and which determines the lowest and highest number.
	User inputs numbers 1 10 99 5 19 -23 17*/

  //1st Method
  function test(){
    const arr=[1,10,99,5,19,-23,17];
    var max=Math.max(...arr);
    var min=Math.min(...arr);
    
    Log.Message("Max no is: "+max+" Min no is: "+min);
  }
  
  //2nd Method
  function getMaxOfArray(numArray) {
    return Math.max.apply(null, numArray);
}
 function getMinOfArray(numArray) {
    return Math.min.apply(null, numArray);
}

function main(){
  var arr=[1,10,99,5,19,-23,17];
  var max=getMaxOfArray(arr);
  var min=getMinOfArray(arr);
  Log.Message("Max no is: "+max+" Min no is: "+min);
  
 
 } 
